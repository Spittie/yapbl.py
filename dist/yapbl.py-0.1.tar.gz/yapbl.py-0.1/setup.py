from distutils.core import setup

setup(
    name='yapbl.py',
    version='0.1',
    packages=[''],
    url='',
    license='ISC',
    author='Spittie',
    author_email='spittiepie@gmail.com',
    description='Yet Another PushBullet Library'
)
